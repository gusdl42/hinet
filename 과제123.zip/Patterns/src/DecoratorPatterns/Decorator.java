package DecoratorPatterns;

public class Decorator {
    public String getHello(){
        return "Hello";
    }
}