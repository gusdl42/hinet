package DecoratorPatterns;

public class Test {
    public static void main(String[] args) {
        Decorator decorator = new Decorator();
        System.out.println(decorator.getHello());
        Decorator child = new ChildDecorator(decorator);
        System.out.println(child.getHello());
        Decorator child2 = new ChildDecorator(child);
        System.out.println(child2.getHello());
    }
    //http://iilii.egloos.com/3850836
}
