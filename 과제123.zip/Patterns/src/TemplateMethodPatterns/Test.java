package TemplateMethodPatterns;

public class Test {
    public static void main(String[] args) {
        Worker designer = new Designer();
        designer.work();
        Worker gamer = new Gamer();
        gamer.work();
    }
    //http://iilii.egloos.com/3806897
    //http://sdw8001.tistory.com/122
    //https://www.google.co.kr/search?q=%EB%94%94%EC%9E%90%EC%9D%B8%ED%8C%A8%ED%84%B4+%EC%A2%85%EB%A5%98&rlz=1C1ASRM_enKR675KR676&oq=%EB%94%94%EC%9E%90%EC%9D%B8%ED%8C%A8%ED%84%B4+%EC%A2%85%EB%A5%98&aqs=chrome..69i57.6652j0j7&sourceid=chrome&ie=UTF-8
}